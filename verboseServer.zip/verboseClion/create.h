//
// Created by Samuel on 11/26/19.
//

#ifndef UNTITLED_CREATE_H
#define UNTITLED_CREATE_H
int create(char *var1, int var2, int partition,char *fullArray, int fullArraySize,int bodyStart);
#endif //UNTITLED_CREATE_H
