//
// Created by Samuel on 11/27/19.
//

#ifndef UNTITLED_DELETE_H
#define UNTITLED_DELETE_H
int deleteAll(char *var1, int var2);
#endif //UNTITLED_DELETE_H
