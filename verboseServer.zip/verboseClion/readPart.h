//
// Created by Samuel on 11/26/19.
//

#ifndef UNTITLED_READPART_H
#define UNTITLED_READPART_H
int readPart(char *var1, int var2, int partition,int connection);
#endif //UNTITLED_READPART_H
