//
// Created by Samuel on 11/26/19.
//
#include <stdio.h>
#include <string.h>
#ifndef UNTITLED_READALL_H
#define UNTITLED_READALL_H
int readAll(char *var1, int var2,int connection);
#endif //UNTITLED_READALL_H
