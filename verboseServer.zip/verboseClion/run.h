//
// Created by Samuel on 11/27/19.
//

#ifndef UNTITLED_RUN_H
#define UNTITLED_RUN_H
int run(char *var1, int var2,int connection,char*bodyArray,int bodyLength);
#endif //UNTITLED_RUN_H
