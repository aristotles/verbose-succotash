//
// Created by Samuel on 12/6/19.
//

#ifndef UNTITLED_HANDLETHEREQUEST_H
#define UNTITLED_HANDLETHEREQUEST_H
void * handleTheRequest(void * request);
#endif //UNTITLED_HANDLETHEREQUEST_H
